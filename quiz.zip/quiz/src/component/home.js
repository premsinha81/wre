import Slider from "./slider"
import Popup from "./Popup"


function Home() {
    return (
        
        <>
         
            <Slider></Slider>
            <Popup></Popup>
            
        </>
    )
}

export default Home