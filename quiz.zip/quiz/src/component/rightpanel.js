const RightPanel = (props) => {

    setTimeout(() => {
        console.log(props)
    },'5000')
    
    return (
        <></>
    )
}
export default RightPanel