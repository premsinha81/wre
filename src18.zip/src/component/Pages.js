import React from 'react'

const Pages = () => {
  return (
    <div>hello</div>
  )
}

export default Pages