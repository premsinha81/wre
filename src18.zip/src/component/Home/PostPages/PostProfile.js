import { Avatar, Box, Button, Grid, InputBase, Stack, Typography } from '@mui/material'
import React, { useState } from 'react'
import CusButton from './CusButton2'
import WatchLaterIcon from '@mui/icons-material/WatchLater';
import HomeSlider from './HomeSlider';
import PollRoundedIcon from '@mui/icons-material/PollRounded';
import CropOriginalRoundedIcon from '@mui/icons-material/CropOriginalRounded';
import LuggageRoundedIcon from '@mui/icons-material/LuggageRounded';
import CallToActionRoundedIcon from '@mui/icons-material/CallToActionRounded';
import AddPost from './AddPost';
import PostTimer from './PostTimer';

const PostProfile = ({onClick, onclick}) => {

    const [timer , setTimer]=useState(false)

    const userName = localStorage.getItem("usr_name")


  return (
    
   <Grid container sx={{p:0,justifyContent:"right"}} >

   

    <Grid item xs={12}>

         
        <Stack direction={{xs:"row",sm:"row"}} spacing={0} className='w-100 rounded-pill border' sx={{justifyContent:"space-between",alignItems:"center",p:"5px",bgcolor:"#fff"}} >
            <Box>
                <Avatar className='img_s' src='./img1.png'  sx={{width:{lg:45,sm:35,xs:40},height:{lg:45,sm:35,xs:40}}}/>
            </Box>
           
                <InputBase onClick={onClick} className='form-control border-0 fs10-s ps-0' placeholder={userName} />
           
            <Stack direction="row" spacing={1} sx={{justifyContent:"space-between",alignItems:"center"}}>
           
            <Box>
                
                <PostTimer/>

                <WatchLaterIcon sx={{width:{lg:30,xs:22},height:{lg:30,xs:22},color:"#616161",display:{sm:"none"}}} onClick={()=>setTimer(!timer)} />
               
            </Box>
            <CusButton name={<Typography onClick={onclick} className='px-2 px-lg-0 fs10-s' sx={{py:{lg:"2px",xs:"1px"},fontSize:{lg:"15px",xs:"14px"}}} >Post</Typography>} color="#fff" bgcolor="#3D55A5" size={"20px"}/>
            </Stack>
        </Stack>
   
    </Grid>
{/* 
    <Grid item xs={11} sx={{my:{lg:2,xs:1}}}>
    
   <Stack direction="row" spacing={2}>
            <Box><CropOriginalRoundedIcon sx={{color:"black"}}/></Box>
           <Box> <PollRoundedIcon sx={{color:"black"}}/></Box>
           <Box> <LuggageRoundedIcon sx={{color:"black"}}/></Box>
           <Box> <CallToActionRoundedIcon sx={{color:"black"}}/></Box>
        </Stack>
   </Grid>*/}
    
   

    

    <Grid item xs={12} sx={{my:{lg:3,xs:0}}}>
       <Stack direction={"row"} spacing={0} sx={{flexWrap:"wrap",justifyContent:{xs:"left"}}}>

     
      
       <CusButton 
       
        name={
        <Stack direction="row" spacing={1} sx={{justifyContent:"center",alignItems:"center"}}>
            <Box><i className="fa fa-line-chart"></i></Box>
            <Box>Trending</Box>
        </Stack>
        }
        bgcolor={"#FFA845"}
        color={"#fff"}
        size={"14px"}
        />
      

       
        <CusButton
         
        name={
        <Stack direction="row" spacing={1} sx={{justifyContent:"center",alignItems:"center"}}>
            <Box><i className="fa fa-leaf"></i></Box>
            <Box>Fresh</Box>
        </Stack>
        }
        bgcolor={"#3D55A5"}
        color={"#fff"}
        size={"14px"}
        alignItems={"center"}
        />
       

      
        <CusButton
         
        name={
        <Stack direction="row" spacing={1} sx={{justifyContent:"center",alignItems:"center"}}>
            <Box><i className="fa fa-thumb-tack"></i></Box>
            <Box>Following</Box>
        </Stack>
        }
        bgcolor={"#3D55A5"}
        alignItems={"center"}
        color={"#FFFFFF"}
        size={"14px"}
        />
      

       
       <CusButton 
        alignItems={"center"}
        name={"Welding"}
        bgcolor={"#3C3C3C"}
        color={"#FFFFFF"}
        size={"14px"}
        />
      

        
        <CusButton
          alignItems={"center"}
        name={"Courses"}
        bgcolor={"#3C3C3C"}
        color={"#FFFFFF"}
        size={"14px"}
        />
       
        
       
        <CusButton
          alignItems={"center"}
        name={"Philadelphia"}
        bgcolor={"#3C3C3C"}
        color={"#FFFFFF"}
        size={"14px"}
        />
      
        
       
        <CusButton
          alignItems={"center"}
        name={"Jobs"}
        bgcolor={"#3C3C3C"}
        color={"#FFFFFF"}
        size={"14px"}
        />
        
        
       
        <CusButton
         place-items={"center"}
        name={"Institutes"}
        bgcolor={"#3C3C3C"}
        color={"#FFFFFF"}
        size={"14px"}
        text-align={"center"}
        style={"text-align='center'"}
        />
       



       </Stack>
    </Grid>

   </Grid>
  )
}

export default PostProfile