import { IMG01, IMG02, IMG03, IMG04, IMG05 } from "../client/components/pages/searchdoctor/searchList/img"


const Data ={
    cardData:[
        {
            id:1,
            img:IMG01,
            fullname:'Dr. Ruby Perrin',
            title:'MDS - Periodontology and Oral Implantology, BDS',
            desc:'dentist',
            number:'(17)',
            city:'Newyork,USA'
           
        },

        {
            id:2,
            img:IMG02,
            title:'mohit1',
            fullname:'rajput'
        },

        {
            id:3,
            img:IMG03,
            title:'mohit2',
            fullname:'rajput'
        },

        {
            id:4,
            img:IMG04,
            title:'mohit3',
            fullname:'rajput'
        },

        {
            id:5,
            img:IMG05,
            title:'mohit4',
            fullname:'rajput'
        }


    ]

}

export default Data